console.log("Hello Winc Academy");
let firstName = 'Thijmen';
let x = 4;
let y = 8;
let z = 40;
console.log(x + x);
console.log(firstName);
console.log(z / x - x);
console.log(x * y / z);
console.log(z % x);
let leeftijd = 48;
console.log(leeftijd)
console.log(typeof leeftijd);
leeftijd = '48';
console.log(leeftijd)
console.log(typeof leeftijd);