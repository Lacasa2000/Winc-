console.log("Hallo Winc Academy studenten")

// Som 1 vermeningvuldigen ( Dit is een grote som)
<p id="demo"></p>

let x = 1230941;
let y = 1823794;
let z = x * y;
document.getElementById("demo").innerHTML = z;

// Som 2 delen
<p id="demo"></p>

let x = 637263;
let y = 54;
let z = x / y;
document.getElementById("demo").innerHTML = z; 